const netFlixBackground="https://assets.nflxext.com/ffe/siteui/vlv3/75b0ed49-75ab-4a63-bd45-37bc2c95cb73/web/IN-en-20250623-TRIFECTA-perspective_ae5833b7-6ce5-4e88-853e-014f38c506f1_medium.jpg";
const netFlixLogo="https://upload.wikimedia.org/wikipedia/commons/0/08/Netflix_2015_logo.svg"
const userIcon="https://imgs.search.brave.com/AlYMm2zdt_6EOuEMBZumewK-qMl7bTZYElBK_X00PG4/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93d3cu/c3ZncmVwby5jb20v/c2hvdy8yOTQ4MjYv/dXNlci1wcm9maWxl/LnN2Zw"
const CDNImageURL="https://image.tmdb.org/t/p/w300/"
export {CDNImageURL,netFlixBackground,netFlixLogo,userIcon};