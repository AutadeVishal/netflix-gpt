export default function DisclaimerBanner() {
  return (
    <div className="fixed top-0 left-0 w-full bg-yellow-200 text-black p-3 z-50">
      {/* Your disclaimer text */}
      <p className="text-center">This is not afflicated to netflix ,its a clone UI alongwith gpt search feature ,</p>
    </div>
  );
}